document.addEventListener("DOMContentLoaded", function () {
    const textInput = document.getElementById("text-input");
    const qrBox = document.querySelector(".qr-box");
    const generateBtn = document.getElementById("generate-btn");

    generateBtn.addEventListener("click", function () {
        let text = textInput.value.trim();

        if (text === "") {
            alert("Please enter text or a URL!");
            return;
        }

        let qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(text)}`;

        qrBox.innerHTML = "";

        let qrImage = document.createElement("div");
        qrImage.style.backgroundImage = `url('${qrCodeUrl}')`;
        qrImage.style.width = "150px";
        qrImage.style.height = "150px";
        qrImage.style.backgroundSize = "cover";

        qrBox.appendChild(qrImage);
    });
});

document.addEventListener("DOMContentLoaded", function() {
    let qrImage = document.getElementById("qr-image");
    let textInput = document.getElementById("text-input");
    let generateBtn = document.getElementById("generate-btn");

    qrImage.src = "default.jpeg"; 

    generateBtn.addEventListener("click", function() {
        let inputValue = textInput.value.trim();

        if (inputValue === "") {
            alert("Please enter text or URL");
            return;
        }
        let qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(inputValue)}`;
        
        qrImage.src = qrCodeUrl;
    });
});
