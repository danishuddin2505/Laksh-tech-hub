document.getElementById('start-counting').addEventListener('click', function() {
    countUp('staff-count', 50);
    countUp('clients-count', 100);
    countUp('tieup-count', 150);
    countUp('students-count', 200);
    countUp('projects-count', 250);
    countUp('running-count', 300);
});

function countUp(id, max) {
    let num = 0;
    let speed = Math.ceil(2000 / max); 
    let element = document.getElementById(id);
    
    let interval = setInterval(() => {
        if (num >= max) {
            clearInterval(interval);
            element.textContent = max;
        } else {
            num++;
            element.textContent = num;
        }
    }, speed);
}

document.addEventListener("DOMContentLoaded", function () {
    if (window.innerWidth <= 750) { 
        let statsSection = document.querySelector(".stats-section");
        statsSection.style.height = "auto"; 
        statsSection.style.minHeight = "100vh"; 
        statsSection.style.backgroundColor = "rgb(245, 204, 2)"; 
        
        let startButton = document.getElementById("start-counting");
        startButton.style.marginTop = "-10px"; 

        let footer = document.querySelector(".footer");
        footer.style.position = "relative"; 
        footer.style.marginTop = "1px"; 
    }
});

