// Data structure for locations (2 cities, 2 talukas, 2 villages each)
const locationData = {
    india: {
        states: {
            maharashtra: {
                cities: {
                    mumbai: {
                        talukas: {
                            andheri: ["Village A", "Village B"],
                            bandra: ["Village C", "Village D"]
                        }
                    },
                    pune: {
                        talukas: {
                            kothrud: ["Village E", "Village F"],
                            hinjewadi: ["Village G", "Village H"]
                        }
                    }
                }
            },
            gujarat: {
                cities: {
                    ahmedabad: {
                        talukas: {
                            maninagar: ["Village I", "Village J"],
                            naroda: ["Village K", "Village L"]
                        }
                    },
                    surat: {
                        talukas: {
                            adajan: ["Village M", "Village N"],
                            varachha: ["Village O", "Village P"]
                        }
                    }
                }
            }
        }
    },
    america: {
        states: {
            california: {
                cities: {
                    losangeles: {
                        talukas: {
                            downtown: ["Village Q", "Village R"],
                            hollywood: ["Village S", "Village T"]
                        }
                    },
                    sanfrancisco: {
                        talukas: {
                            bayarea: ["Village U", "Village V"],
                            siliconvalley: ["Village W", "Village X"]
                        }
                    }
                }
            },
            texas: {
                cities: {
                    houston: {
                        talukas: {
                            sugarland: ["Village Y", "Village Z"],
                            katy: ["Village AA", "Village BB"]
                        }
                    },
                    dallas: {
                        talukas: {
                            plano: ["Village CC", "Village DD"],
                            irving: ["Village EE", "Village FF"]
                        }
                    }
                }
            }
        }
    },
    china: {
        states: {
            beijing: {
                cities: {
                    dongcheng: {
                        talukas: {
                            chaoyang: ["Village GG", "Village HH"],
                            haidian: ["Village II", "Village JJ"]
                        }
                    },
                    xicheng: {
                        talukas: {
                            fengtai: ["Village KK", "Village LL"],
                            shijingshan: ["Village MM", "Village NN"]
                        }
                    }
                }
            },
            shanghai: {
                cities: {
                    pudong: {
                        talukas: {
                            lujiazui: ["Village OO", "Village PP"],
                            xuhui: ["Village QQ", "Village RR"]
                        }
                    },
                    jingan: {
                        talukas: {
                            zhangjiang: ["Village SS", "Village TT"],
                            changning: ["Village UU", "Village VV"]
                        }
                    }
                }
            }
        }
    }
};

// Selecting elements
const countrySelect = document.getElementById("country");
const stateSelect = document.getElementById("state");
const citySelect = document.getElementById("city");
const talukaSelect = document.getElementById("taluka");
const villageSelect = document.getElementById("village");
const saveBtn = document.getElementById("saveBtn");
const detailsList = document.getElementById("detailsList");

// Function to populate options dynamically
function populateOptions(selectElement, options) {
    selectElement.innerHTML = '<option value="">Select</option>';
    Object.keys(options).forEach(option => {
        let newOption = document.createElement("option");
        newOption.value = option;
        newOption.textContent = option.charAt(0).toUpperCase() + option.slice(1);
        selectElement.appendChild(newOption);
    });
}

// On country change -> update states
countrySelect.addEventListener("change", function () {
    const selectedCountry = countrySelect.value;
    if (selectedCountry && locationData[selectedCountry]) {
        populateOptions(stateSelect, locationData[selectedCountry].states);
        citySelect.innerHTML = talukaSelect.innerHTML = villageSelect.innerHTML = '<option value="">Select</option>';
    }
});

// On state change -> update cities
stateSelect.addEventListener("change", function () {
    const selectedCountry = countrySelect.value;
    const selectedState = stateSelect.value;
    if (selectedCountry && selectedState && locationData[selectedCountry].states[selectedState]) {
        populateOptions(citySelect, locationData[selectedCountry].states[selectedState].cities);
        talukaSelect.innerHTML = villageSelect.innerHTML = '<option value="">Select</option>';
    }
});

// On city change -> update talukas
citySelect.addEventListener("change", function () {
    const selectedCountry = countrySelect.value;
    const selectedState = stateSelect.value;
    const selectedCity = citySelect.value;
    if (selectedCountry && selectedState && selectedCity && locationData[selectedCountry].states[selectedState].cities[selectedCity]) {
        populateOptions(talukaSelect, locationData[selectedCountry].states[selectedState].cities[selectedCity].talukas);
        villageSelect.innerHTML = '<option value="">Select</option>';
    }
});

// On taluka change -> update villages
talukaSelect.addEventListener("change", function () {
    const selectedCountry = countrySelect.value;
    const selectedState = stateSelect.value;
    const selectedCity = citySelect.value;
    const selectedTaluka = talukaSelect.value;
    if (selectedCountry && selectedState && selectedCity && selectedTaluka) {
        const villageList = locationData[selectedCountry].states[selectedState].cities[selectedCity].talukas[selectedTaluka];
        populateOptions(villageSelect, villageList.reduce((acc, village) => {
            acc[village] = village;
            return acc;
        }, {}));
    }
});

// Save Button functionality
saveBtn.addEventListener("click", function () {
    const selectedCountry = countrySelect.value;
    const selectedState = stateSelect.value;
    const selectedCity = citySelect.value;
    const selectedTaluka = talukaSelect.value;
    const selectedVillage = villageSelect.value;

    if (!selectedCountry || !selectedState || !selectedCity || !selectedTaluka || !selectedVillage) {
        alert("Please select all fields!");
        return;
    }

    // Creating a list item
    const listItem = document.createElement("li");
    listItem.innerHTML = `
        <strong>Country:</strong> ${selectedCountry.toUpperCase()}, 
        <strong>State:</strong> ${selectedState.toUpperCase()}, 
        <strong>City:</strong> ${selectedCity.toUpperCase()}, 
        <strong>Taluka:</strong> ${selectedTaluka.toUpperCase()}, 
        <strong>Village:</strong> ${selectedVillage.toUpperCase()} 
        <button class="delete-btn">Clear</button>
    `;

    // Add delete functionality
    listItem.querySelector(".delete-btn").addEventListener("click", function () {
        listItem.remove();
    });

    // Append the saved details
    detailsList.appendChild(listItem);

    // Reset the form
    countrySelect.value = stateSelect.value = citySelect.value = talukaSelect.value = villageSelect.value = "";
    stateSelect.innerHTML = citySelect.innerHTML = talukaSelect.innerHTML = villageSelect.innerHTML = '<option value="">Select</option>';
});


