document.addEventListener('DOMContentLoaded', function () {
    const imageContainer = document.getElementById('imageContainer');

    // 🔹 Add Image Button
    const toggleButton = document.createElement('button');
    toggleButton.textContent = 'Add Image';
    toggleButton.id = 'toggleImage';
    imageContainer.appendChild(toggleButton);

    // 🔹 Image Create Karna
    const image = document.createElement('img');
    image.id = 'mainImage';
    image.style.display = 'none';
    image.style.width = '300px';
    image.style.height = '200px';
    image.style.position = 'relative'; 
    imageContainer.appendChild(image);

    // 🔹 Overlay Text Create Karna
    let overlayText = document.createElement('div');
    overlayText.id = 'overlayText';
    overlayText.style.position = 'absolute';
    overlayText.style.top = '50%';
    overlayText.style.left = '50%';
    overlayText.style.transform = 'translate(-50%, -50%)';
    overlayText.style.color = 'white';
    overlayText.style.fontSize = '20px';
    imageContainer.appendChild(overlayText);

    // 🔹 Button Click Event Listener
    toggleButton.addEventListener('click', function () {
        if (image.style.display === 'none') {
            image.src = 'your-image.jpg'; 
            image.style.display = 'block';
            toggleButton.textContent = 'Remove Image';
        } else {
            image.style.display = 'none';
            toggleButton.textContent = 'Add Image';
        }
    });

    // 🔹 Text Input Functionality
    document.getElementById('textInput').addEventListener('input', function () {
        let overlayText = document.getElementById('overlayText'); 
        overlayText.textContent = this.value;
        overlayText.style.color = "red";
    });

    // 🔹 Font Size Control
    document.getElementById('fontSize').addEventListener('input', function () {
        overlayText.style.fontSize = this.value + 'px';
    });

    // 🔹 Arrow Button Movement
    document.getElementById('up').addEventListener('click', function () {
        moveText(0, -10);
    });
    document.getElementById('down').addEventListener('click', function () {
        moveText(0, 10);
    });
    document.getElementById('left').addEventListener('click', function () {
        moveText(-10, 0);
    });
    document.getElementById('right').addEventListener('click', function () {
        moveText(10, 0);
    });

    // 🔹 Opacity Control
    document.getElementById('opacity').addEventListener('input', function () {
        image.style.opacity = this.value;
    });

    // 🔹 Filters Functionality
    document.getElementById('blur').addEventListener('input', updateFilters);
    document.getElementById('borderRadius').addEventListener('input', function () {
        image.style.borderRadius = this.value + 'px';
    });
    document.getElementById('brightness').addEventListener('input', updateFilters);
    document.getElementById('saturation').addEventListener('input', updateFilters);

    function updateFilters() {
        let brightness = document.getElementById('brightness').value;
        let saturation = document.getElementById('saturation').value;
        let blur = document.getElementById('blur').value;
        image.style.filter = `brightness(${brightness}) saturate(${saturation}) blur(${blur}px)`;
    }

    // 🔹 Move Text Function
    function moveText(x, y) {
        let topValue = parseInt(overlayText.style.top) || 50;
        let leftValue = parseInt(overlayText.style.left) || 50;
        overlayText.style.top = (topValue + y) + 'px';
        overlayText.style.left = (leftValue + x) + 'px';
    }

     

});

document.addEventListener('DOMContentLoaded', function () {
    let button = document.getElementById('toggleImage');
    button.style.position = "absolute";
    button.style.bottom = "-1px"; 
    button.style.left = "39%";
    button.style.transform = "translatey(-50%)";
}); 


document.addEventListener("DOMContentLoaded", function () {
    let overlayText = document.getElementById("overlayText");
    let textInput = document.getElementById("textInput");
    let fontSizeInput = document.getElementById("fontSize");
    
    // Initial Position (Center of Image)
    let posX = 50;
    let posY = 50;

    // 🔹 Text Input Change
    textInput.addEventListener("input", function () {
        overlayText.textContent = this.value;
        overlayText.style.color = "red"; // Text color red
    });

    // 🔹 Font Size Adjustment
    fontSizeInput.addEventListener("input", function () {
        overlayText.style.fontSize = this.value + "px";
    });

    // 🔹 Arrows to Move Text
    document.getElementById("up").addEventListener("click", function () {
        posY -= 5;
        overlayText.style.top = posY + "%";
    });

    document.getElementById("down").addEventListener("click", function () {
        posY += 5;
        overlayText.style.top = posY + "%";
    });

    document.getElementById("left").addEventListener("click", function () {
        posX -= 5;
        overlayText.style.left = posX + "%";
    });

    document.getElementById("right").addEventListener("click", function () {
        posX += 5;
        overlayText.style.left = posX + "%";
    });
});
