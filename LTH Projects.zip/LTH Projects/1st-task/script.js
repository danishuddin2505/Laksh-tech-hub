document.querySelectorAll('.color-btn').forEach(button => {
    button.addEventListener('click', () => {
        const color = button.classList[1];
        document.body.style.backgroundColor = color;
        document.querySelector('.button-container').style.backgroundColor = color;
    });
});

