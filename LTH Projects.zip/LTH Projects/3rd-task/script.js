document.addEventListener("DOMContentLoaded", function () {
    const addButton = document.querySelector(".button-style");
    const productNameInput = document.getElementById("product-name");
    const productPriceInput = document.getElementById("product-price");
    const productQuantityInput = document.getElementById("product-quantity");
    const rowContainer = document.getElementById("productTableBody");
    let serialNumber = 1;
    let finalTotal = 0;

    addButton.addEventListener("click", function () {
        const name = productNameInput.value.trim();
        const price = parseFloat(productPriceInput.value);
        const quantity = parseInt(productQuantityInput.value);
        
        if (name === "" || isNaN(price) || isNaN(quantity) || price <= 0 || quantity <= 0) {
            alert("Please enter valid product details!");
            return;
        }

        if (serialNumber > 6) {
            alert("You can only add up to 6 products!");
            return;
        }

        const total = price * quantity;
        finalTotal += total;

        const newRow = document.createElement("tr");
        newRow.innerHTML = `
            <td>${serialNumber}</td>
            <td>${name}</td>
            <td>${price.toFixed(2)}</td>
            <td>${quantity}</td>
            <td>${total.toFixed(2)}</td>
        `;
        rowContainer.appendChild(newRow);

        document.getElementById("final-total").textContent = finalTotal.toFixed(2);

        serialNumber++;
        productNameInput.value = "";
        productPriceInput.value = "";
        productQuantityInput.value = "";
    });
});

